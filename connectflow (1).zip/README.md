# ConnectFlow

Uma plataforma social moderna construída com React, Tailwind CSS e TanStack Start.

## Pré-requisitos

- [Node.js](https://nodejs.org/) (v18 ou superior) ou [Bun](https://bun.sh/)
- Gerenciador de pacotes: `npm`, `yarn`, `pnpm` ou `bun`

## Instalação

1. Extraia o arquivo ZIP em uma pasta de sua preferência.
2. Abra um terminal na pasta do projeto.
3. Instale as dependências:

```bash
bun install
```

Ou, se preferir:

```bash
npm install
```

## Executar localmente

Após a instalação, inicie o servidor de desenvolvimento:

```bash
bun dev
```

Ou:

```bash
npm run dev
```

O aplicativo estará disponível em `http://localhost:3000` (ou na porta indicada no terminal).

## Build para produção

Para gerar uma versão otimizada para produção:

```bash
bun run build
```

Ou:

```bash
npm run build
```

## Estrutura do projeto

- `src/routes/` — Páginas da aplicação (feed, explorar, notificações, perfil, mensagens)
- `src/components/` — Componentes reutilizáveis (Sidebar, Icon, UI)
- `src/styles.css` — Tokens de design e estilos globais

## Tecnologias

- React 19
- TanStack Start / TanStack Router
- Tailwind CSS v4
- TypeScript
- Material Symbols (ícones)
