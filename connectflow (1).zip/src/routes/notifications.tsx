import { createFileRoute } from "@tanstack/react-router";
import { Icon } from "@/components/Icon";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Notificações — ConnectFlow" },
      { name: "description", content: "Acompanhe suas interações e novidades." },
    ],
  }),
  component: NotificationsPage,
});

function NotificationsPage() {
  return (
    <main className="md:ml-64 min-h-screen pb-24 md:pb-0">
      <header className="w-full sticky top-0 z-30 bg-surface-container-lowest shadow-sm">
        <div className="flex items-center justify-between px-lg py-sm max-w-[800px] mx-auto">
          <h2 className="text-title-md text-primary font-bold">Notificações</h2>
          <div className="flex gap-sm">
            <button className="p-base rounded-full hover:bg-surface-container-high transition-colors active:scale-95" title="Filtrar"><Icon name="filter_list" /></button>
            <button className="p-base rounded-full hover:bg-surface-container-high transition-colors active:scale-95" title="Marcar todas como lidas"><Icon name="done_all" /></button>
          </div>
        </div>
      </header>

      <div className="max-w-[800px] mx-auto px-md py-lg">
        <section className="mb-xl">
          <h3 className="text-label-md text-on-surface-variant uppercase tracking-widest mb-md px-md font-semibold">Hoje</h3>
          <div className="grid gap-sm">
            <NotifCard>
              <div className="relative">
                <img alt="" className="w-12 h-12 rounded-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDSFzH1Pun24toOThEyVTNf6bN4BvFJao7iWQ6VD7v7EkfgQXNGqQSMQnj_Wqtmn2gENPB-Mx2BWhUV8ndSXHCrvjHgMos4VeBcCps0L0KDOvE6g9gfH_Jr_1SXX-QRlVf2LuZ_C_ufNXI_98gltAnTuPhfNQSzkQ4lAAszdkHcdgHIMRiOI5ugbjWgdf6Gl063oXHpOVLZFmVaF2XXHTbg6ESv62U6L0a5ZkhD8dpDKPR7kb8NuhyIgIq0p6V_bnERo3U_a-3IZQo" />
                <Badge color="bg-primary"><Icon name="person_add" filled className="!text-[12px] text-white" /></Badge>
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface"><span className="font-bold">Ana Clara</span> começou a seguir você.</p>
                <p className="text-xs text-on-surface-variant mt-xs">há 15 minutos</p>
              </div>
              <button className="bg-primary text-on-primary px-lg py-xs rounded-full font-bold text-xs hover:brightness-110 transition-all active:scale-95">Seguir</button>
            </NotifCard>

            <NotifCard>
              <div className="relative">
                <div className="flex -space-x-4">
                  <img className="w-10 h-10 rounded-full border-2 border-surface-container-lowest object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD8iESJN4XNPCZREmLuet1AFwevHP-SZR6AYrbGBzt1Kjf5cRY_ETCQkkwWLe5L4hSaRToQxv9P9cJ5pnyz_QZvqgY4Yo0_s1JxkKz9fAAWqSfev8rew9PxF90TQbBISEUcNPrvJnIOFZYpEjoRPSoTd8tqMpEDTGSr90QqYfmog5HUmP01tVtCrTxM8IghR7qE4_oVNRuHbAmI9B0sWdsgD6PpTWVC_tTnUMg61Mo74rIesgdKaJNo3qhQdPGINGyl-AyG3hz9aCc" />
                  <img className="w-10 h-10 rounded-full border-2 border-surface-container-lowest object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB7ZKd-Mg7AzcAvb1LZZPBgYpr1JH6OUQGhmvimIepMNoWCv1T6pOqqxpHZ3t7LKImTZIA621Y01jK-OtoGC8jNulLPkHsTV-0tU9ek4knd6wZd7lEWZjy4xA7hRCda2_qDXrRZuJy8WwbsDHwkANJiuPvx3K_4DifUKKwgHhAAkZ9l94oReepVBJnn9Q-PAGGVTu-7YwVjI9MYzkjiphq6HQvw3YSZbHMgNbUEoHshJlKllesc1O6n-GRblAr_Pm917-HKKK7Oz5U" />
                </div>
                <Badge color="bg-secondary"><Icon name="favorite" filled className="!text-[12px] text-white" /></Badge>
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface"><span className="font-bold">Bruno, Carlos</span> e outras <span className="font-bold">12 pessoas</span> curtiram sua foto.</p>
                <p className="text-xs text-on-surface-variant mt-xs">há 2 horas</p>
              </div>
              <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0">
                <img className="w-full h-full object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDdFDA-ztgCkwMQvfsGkcikanVUFjdYPEEoHPofDyz-IX7Wn-VawWGfrR1lIabl-cD9iveGaTbxac1XXZuF6gJtNMSsTYcfLp1TR7e6pBU47dk8O-UPF7Iu5J2WxAdzNRmb3YDuPL-SIuHPtTTWIhf3NDrYBPB7tf3u3I3tLY7zIhDq0gIJsYlouNFQr-Dcf6ii3D4mvfZOaqnziHtREUWb1K1jGyvBmhEhFZvA54wygb77fdJP7kQrxvckLc7ow1kdtSljErqELOw" />
              </div>
            </NotifCard>

            <NotifCard>
              <div className="relative">
                <img className="w-12 h-12 rounded-full object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBey9OzHG7JoWXNRlJuNC9SaVR7plyq3kCHBRO9m3nV6jeVjGq34z_2AksfW4BJox07ICqxWMkh64-YcX9NFb4PwOYfgEGoWbRFHya0Vi6r9SWkZ2GN7KLc3wC7TQxmNpQbHhLi2fAM8lNBeES5qoUD-rqPRDTOLDZlcqqOGXRzfJ8Iw_LBQENJ3zT1Uun6geBbpMwfR_GvqXiVR7wRu5Q6fr8yVAc-IcThxE3AUaQCua9hi5IdvV5z1qaOnXHEuWm2khMwKS0gsNs" />
                <Badge color="bg-tertiary-container"><Icon name="chat_bubble" filled className="!text-[12px] text-on-tertiary-container" /></Badge>
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface"><span className="font-bold">Mariana</span> comentou: "Essa composição ficou simplesmente incrível! Qual lente você usou?"</p>
                <p className="text-xs text-on-surface-variant mt-xs">há 5 horas</p>
                <div className="mt-sm p-sm bg-surface rounded-lg border border-outline-variant text-sm italic text-on-surface-variant">
                  Resposta rápida: "Obrigado! Usei uma 35mm..."
                </div>
              </div>
            </NotifCard>
          </div>
        </section>

        <section>
          <h3 className="text-label-md text-on-surface-variant uppercase tracking-widest mb-md px-md font-semibold">Esta semana</h3>
          <div className="grid gap-sm opacity-90">
            <NotifCard>
              <div className="relative">
                <img className="w-12 h-12 rounded-full object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCKuz-SIjgMybXJgxKYI3qIiiXkI7Lc49ygGTXXUIE8fFXHo-jGZwyNL3UrMyNfJ8Wxgq-9Dta_6iUoGzEQqkPfyrbQWUL8HJi4y8-GGFG4a2chFY-uwLnn8XvWW8R7fCz5Gkv4woijrKibuhvc9ZssVaarvM1jBsLIG_STKoAMNjIQW0hXfwbhpSmihUHloD_6pZJGPJM7YJyNkXhScPSFC1EtcP1QN5KfTwgEwO7kEsokVdd82Cz4v90-qNdrctsDRQqDnBKNx1E" />
                <Badge color="bg-surface-tint"><Icon name="alternate_email" className="!text-[12px] text-white" /></Badge>
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface"><span className="font-bold">Rafael</span> mencionou você em um comentário: "@usuario_conectado dá uma olhada nisso!"</p>
                <p className="text-xs text-on-surface-variant mt-xs">Ontem</p>
              </div>
            </NotifCard>

            <NotifCard>
              <div className="w-12 h-12 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container shrink-0">
                <Icon name="security" />
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface">Seu novo dispositivo foi conectado com sucesso. Se não foi você, revise suas configurações de segurança.</p>
                <p className="text-xs text-on-surface-variant mt-xs">Terça-feira</p>
              </div>
            </NotifCard>

            <NotifCard>
              <div className="w-12 h-12 rounded-full bg-secondary-container flex items-center justify-center text-on-secondary-container shrink-0">
                <Icon name="celebration" />
              </div>
              <div className="flex-1">
                <p className="text-body-md text-on-surface"><span className="font-bold">Parabéns!</span> Seu post "Minha Jornada Tech" alcançou 1.000 curtidas.</p>
                <p className="text-xs text-on-surface-variant mt-xs">Segunda-feira</p>
              </div>
              <button className="text-primary font-bold text-xs hover:underline">Ver post</button>
            </NotifCard>
          </div>
        </section>
      </div>
    </main>
  );
}

function NotifCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-surface-container-lowest p-md rounded-xl shadow-sm flex items-start gap-md hover:bg-surface-container transition-all cursor-pointer border border-transparent hover:border-outline-variant">
      {children}
    </div>
  );
}

function Badge({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <div className={`absolute -right-1 -bottom-1 ${color} w-5 h-5 rounded-full flex items-center justify-center border-2 border-surface-container-lowest`}>
      {children}
    </div>
  );
}
