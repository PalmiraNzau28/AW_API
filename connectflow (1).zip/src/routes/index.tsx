import { createFileRoute } from "@tanstack/react-router";
import { Icon } from "@/components/Icon";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Feed — ConnectFlow" },
      { name: "description", content: "Sua linha do tempo no ConnectFlow." },
    ],
  }),
  component: FeedPage,
});

const STORIES = [
  { name: "Seu Story", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuB2sZgLcjxeRE52WEBufSHdo3QfOU5PsD5BFSSgJ3KLdZhEOLIh0QYRtI25KF7YIpRVTRDUOlhDPxEwkowSOzcUAW3jjYvSE2mL7UsTcTQU2zVI8vpIxLS2K2V-Nz5RAPRIka9eaDcGxveogYRb9e2a70_0dYgw976ZwTjbXphWlCt6AORIJtAWdau5R5BXDQ-l4hrrhyvMLqz6UCGF3x7WFrp6nKCmF7DiCTCy4qwqaMZOoMQ_ByS72Kz3qpCU_TAt6uhiTp98W-U", own: true },
  { name: "ana_marques", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuA40yN-kZQj6_HvOP-TsOuAfU5UAESMOZrICh4QmmXzdTIRHAWZH2ebwRfrxDXWYvCp_JwUprvPN1IEbEP-TNTOlAZ4Lfy-q50u3ZyskrGoTkVorhbLcPXvGk4pi1yqaqHSCY80RQ59y_GDDml02ERP8rdMdQglbSp4Hzt5Dp4_hvGd6aJcrMxBBvkkmW1MIM9dYCleIv9I_N8L4xVW0DK082OELKmePoCCyHW9xpnKLpsmaKlCKaJL3DXv9QokUDvnI8ePDwoF6e4" },
  { name: "dev_lucas", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDlRynKTCOJfl3W5LGu10k8s0xTcE-y9DtAfK6tGu-6Mqwqod1h8q5vqAlQ44ZeLOlGpkM6JNtEhIcKbNqLUD4o3N_odvEOMOM1rGEQCRXbXarcpSlUTyuitFH79nfwJg1BdJuJYB_B64HGUqexNdyZQabL-7V38bT3S4yfJmeuqBMc-D9w-tf3IdblJHDeXLI-edezz5_cMuMkGwAx41T3LPgXU8Pb_upzGDAnLhXd418pehoMkk52wqV_wMzXRGaR3V9BuSOuPL4" },
  { name: "julia.art", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDRrHLeXsuodWSvXvz7xaV4puMKl6z-cMiK8Zb-M1AdbDMdlDQWrkpYSzQ-KLZ4i20deteKKSzgoIACxz_AVzhVZ8-JgZxDFo0-CvuC077tOHB_lpvSnPyf9TvnpzaBogCiRfFxK845P9GuFvOVqnlj0xTe4E9g4DhViPmGerGZ0FVwIU1bjfVkN6aM88aoAbLha6zTFUx84RYGjPKS58xipI7NcmzsnFF4ddFqZWgL09PF2Hv6B0u_9lEs5sqGSz_upuqrS_TJUlE" },
  { name: "carlos_v", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuD-s93zjcL9A-efwV_1dqMjih-9-hyZReHe1OlL1VsVMb5SnuUhQ17YiReBFBtbfcCYVxYWV3aVbmoNlRCmwTB2CRI5i4-DNVoe6OJsftYWDh2yPQJf-SvMW1ScltJ5uWQSicELVixDnKwDo4oz2OsDpRgZVdqQ_bWel7SyVc0XqT_iLHu-UCfIkVr5yz1u-UppMwogam7vhy2u1LazJ8sn6cIBPMpTts1nfRjVBtHbbVZhecAakrgwDa0ZPLIRECaUBGRlfwr42uM" },
];

const TRENDS = [
  { cat: "Tecnologia • Assunto do momento", tag: "#ConnectFlow2024", posts: "45.2k posts" },
  { cat: "Design • Em alta em Brasil", tag: "Material Design 3", posts: "12.8k posts" },
  { cat: "Negócios • Tendência", tag: "IA Generativa", posts: "8.1k posts" },
];

const SUGGESTED = [
  { name: "Bruno Silva", handle: "@brunosilva", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAwZK4wdU0SS6n1U_u-t6FGPFeoWS8AdI5ZdflH1HzbW8m5_68_1jqAI_parKGzzO1V5GPQO9weDXY8iRMj_hKjRVZ4oiuxyMyIAyVjk0YwXC6MpAxrH3itQxN0T0gSsYGulHuxmuzN4ZcQ1C7RpeSm7nseM6LTTMkcO42Bu6jTHccQ1uPGEIQ8AtdazWka0kA4eizRNr6Bp89bTpt1MogzDPt6BUyzEn3pJZA-Be3aB10dI-B3DsdrJSuOaPXy5SB4TkQaeCeiZ6s" },
  { name: "Marta Costa", handle: "@martacosta_ux", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuBEXZU_-8yHko67Tdd9QKnkqyY1Qq_3hl3gJ4CW3jreDpTJXWYZZn3ADUmMtxvkaLIaY48sJVJoBLV_Ov331M4EfBMWa46Y2ZwEeoAwCpbfp4srDtEtQhQUgxEiA7-NXVKFg6i-oCTNCtEZL82aaT3HXmO3fc1SJa05DG-KXC_t2u-Lno2yO1Se7YvJeuT1WeYUz3tIh5gw_miNLlvA32E6cS8L2OE9OvyJXe1vGhODKwGBmyMv_hO444eVGmQHN59RPAPBBFs44UM" },
  { name: "Tech Hub", handle: "@tech_hub_br", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAskvpU13AOHoIjupPScZAuKwFax3zJUwwv9sRqNIreRXqS3frPzc4hFfuOcizYgLk3RjMW4AsnUV9IsB3p_BraHBLpx8nc4DMj93TtsSa450MMhApeE9JluPfIewBtBhUDMTVX3tXBN59AWpIEPRq2WR6pbyjIjAlJHiaidf8jWojSoXIVALpQhDnReRamaR0iZ2fztXig41zPwPip5BGlYNcJYucyrjC68-3Vw-lehmoRViPM3X_smZJquWCOQ6ZEYHOFPZOJV4g" },
];

function FeedPage() {
  return (
    <div className="md:ml-64 lg:mr-[350px] min-h-screen">
      <main className="max-w-2xl mx-auto p-lg pb-24 md:pb-lg">
        <header className="sticky top-0 bg-surface/80 backdrop-blur-md z-30 -mx-lg px-lg py-sm mb-lg flex items-center justify-between border-b border-outline-variant/30">
          <h1 className="text-headline-lg-mobile md:text-headline-lg font-bold text-on-surface">Feed</h1>
          <div className="relative hidden sm:block">
            <span className="absolute left-3 top-1/2 -translate-y-1/2"><Icon name="search" className="text-outline" /></span>
            <input
              type="text"
              placeholder="Pesquisar no ConnectFlow"
              className="pl-10 pr-lg py-sm bg-surface-container-low border-none rounded-full w-64 focus:ring-2 focus:ring-primary focus:bg-surface-container-lowest transition-all outline-none"
            />
          </div>
        </header>

        {/* Stories */}
        <section className="flex gap-md overflow-x-auto hide-scrollbar mb-xl pb-base">
          {STORIES.map((s) => (
            <div key={s.name} className="flex flex-col items-center gap-xs shrink-0 cursor-pointer group">
              <div className={`w-16 h-16 rounded-full p-[2px] border-2 ${s.own ? "border-primary" : "border-secondary-container"} group-hover:scale-105 transition-transform`}>
                <img alt={s.name} className="w-full h-full rounded-full object-cover" src={s.img} />
              </div>
              <span className="text-[10px] font-medium text-on-surface-variant">{s.name}</span>
            </div>
          ))}
        </section>

        {/* Composer */}
        <div className="bg-surface-container-lowest rounded-xl p-md mb-xl shadow-sm border border-outline-variant/30 transition-all hover:shadow-md">
          <div className="flex gap-md">
            <img alt="" className="w-12 h-12 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCnKseKLQZuzBRXRKGIvr8cybmXFd2kV3JeAZwUAz7MkeNr_-RP5P8txL_JflOpomN6x_PsCJla0AzXipeTcGe0MnM9cI0Xe4XYnntaL7Lqdar05mE7FcUYelCWYi2tte3MpiU7l54eWx_5ebpJi1FT9om1g8hA6Yblz3xJA07qLCzdJcp-JdK0piJzBdvAVk9czvMEu6OgERyovHfTxldgkRZXwvb0i3TVzvaahWWIZomGhKA1glipV0oOwtPZ7pjNRfZGjJNUf2Q" />
            <textarea
              rows={2}
              placeholder="O que está acontecendo agora?"
              className="flex-1 bg-transparent border-none focus:ring-0 text-body-lg resize-none pt-2 outline-none"
            />
          </div>
          <div className="flex justify-between items-center mt-md pt-sm border-t border-outline-variant/30">
            <div className="flex gap-sm">
              <button className="p-sm hover:bg-surface-container-high rounded-full text-primary transition-colors"><Icon name="image" /></button>
              <button className="p-sm hover:bg-surface-container-high rounded-full text-tertiary transition-colors"><Icon name="gif_box" /></button>
              <button className="p-sm hover:bg-surface-container-high rounded-full text-secondary transition-colors"><Icon name="sentiment_satisfied" /></button>
            </div>
            <button className="bg-primary text-on-primary px-lg py-sm rounded-full font-bold shadow-sm active:scale-95 transition-transform">Postar</button>
          </div>
        </div>

        {/* Posts */}
        <div className="space-y-lg">
          <article className="bg-surface-container-lowest rounded-xl shadow-sm border border-outline-variant/20 overflow-hidden transition-all hover:shadow-md">
            <div className="p-md flex items-center justify-between">
              <div className="flex items-center gap-sm">
                <img alt="" className="w-10 h-10 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuALx65NzrDJpxAyRr2m57CqH85VSsIliJccFpe1-P7mcCJPcr5_2maieVv9T56kghAodl_t3US7IpIt2osPsqo6bwkDATXJgE_8szIBcjN4iNlPCzinXsrQIsWB8aqWjE9j6TgXUr5W-StxJCrqb3vdK2Tsuj4NzXNES0u5h3KfNozt7XPurRUKrhCd3RiPdiAfc8s8GmDf20Kexgr285Lk97I5uuCPcwgubZR9pC1upL3dFA1P5n9xqN41n5k50FVQ7nhPkAgjF4A" />
                <div>
                  <h3 className="font-bold text-on-surface">Julia Mendes</h3>
                  <p className="text-xs text-on-surface-variant">@julia.art • 2h</p>
                </div>
              </div>
              <button className="p-sm hover:bg-surface-container-high rounded-full"><Icon name="more_horiz" /></button>
            </div>
            <div className="px-md pb-md">
              <p className="text-body-md text-on-surface mb-md">Finalizei essa nova peça digital hoje! O que acharam da paleta de cores? 🎨✨ #artedigital #design #workflow</p>
            </div>
            <div className="aspect-video relative group">
              <img className="w-full h-full object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDU3-iAzYcyVeficWuN7lOm_C71dqOdYapZR_Jb0CK42IPUQ8OCNrKoEKQeLwQj2W1-ms7FJXwysshfXjmXRrZAAG-kEw7EfajokgIZQQvy6kFeeSQ4LYOy6aRfGaXX-HXAAejiAc_vR2BZf-5IILdqgjyoz1uychd7kTjg7YkqmabrCDGd7Mz02Q_R7SNlGDsRnyqDEuftiZ8Sf7u50HBWoKBteJZOwsiPkTEPcN8f7PhaQxRzy32wr8SZkei1R9_8rL0JxQgEWzk" />
            </div>
            <div className="p-md flex items-center gap-xl border-t border-outline-variant/10">
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-secondary transition-colors"><Icon name="favorite" /><span className="text-xs font-bold">1.2k</span></button>
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-primary transition-colors"><Icon name="chat_bubble" /><span className="text-xs font-bold">84</span></button>
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-tertiary transition-colors"><Icon name="share" /><span className="text-xs font-bold">12</span></button>
            </div>
          </article>

          <article className="relative p-xl rounded-xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-outline-variant/20 overflow-hidden">
            <div className="flex items-center gap-sm mb-lg">
              <img alt="" className="w-10 h-10 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC96P4kZl2FqWgWiOh-EF8SfeQf_7FyJMkVP89g-cuLIUrOV8Gdayj5VPWxQp-EDq8tTeFhY08YveJe588W0ng78DEmeaRjzl6ZTAFTwPJhr3JriGDtk9Y9FdNeRW1DZdANziFA34PG7Ez-Ou5Lm3Zp18_WdincU08xmqlwPOl7BwSQsV_k6ZA4emYLORwgkrruuPjVV2JaQnhrzOQjSJA0emu_INTuguaExm1ca4LnwsZSDTnrquKtihk1YCzcsAaJxV4DO4nkbkg" />
              <div>
                <h3 className="font-bold text-on-surface">Lucas Oliveira</h3>
                <p className="text-xs text-on-surface-variant">@dev_lucas • 5h</p>
              </div>
            </div>
            <blockquote className="text-headline-lg-mobile italic text-primary font-bold leading-tight mb-lg">
              "A tecnologia deve ser uma ponte para a conexão humana, não um muro. O futuro do design é empático e fluido."
            </blockquote>
            <div className="flex items-center gap-xl">
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-secondary transition-colors"><Icon name="favorite" filled /><span className="text-xs font-bold">428</span></button>
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-primary transition-colors"><Icon name="chat_bubble" /><span className="text-xs font-bold">15</span></button>
            </div>
          </article>

          <article className="bg-surface-container-lowest rounded-xl shadow-sm border border-outline-variant/20 overflow-hidden">
            <div className="p-md flex items-center gap-sm">
              <img alt="" className="w-10 h-10 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC5Q_oqOvCA2do9ap9EBLjKjGGsZGYf1FmnM4gZ-IKxYTkSYOpdU0N_ByqpF4GyWFFu04KEobNKJqoolSyjCJvoDWi8wYmXZ7829Flfbg3tWd8z3EiC0kUTQBaeVYS_lz16IVjvvoqX1esb0LeBV-97ceVl74DSbu4ZSI3kWdNBnYN3evhhT8KaEE_sWW5BcV0r3aeMTgyb_U9POVAWjybAj-juQT9Ukggl3ON5aDFa-x7iTrBcDzfuBNiq2uYyVDTWcTu3a6xjQx0" />
              <div>
                <h3 className="font-bold text-on-surface">Carla Rocha</h3>
                <p className="text-xs text-on-surface-variant">@carla_tech • 8h</p>
              </div>
            </div>
            <div className="px-md pb-md">
              <p className="text-body-md text-on-surface mb-md">Café e código. A combinação perfeita para uma tarde produtiva de terça-feira. ☕️💻</p>
              <div className="grid grid-cols-2 gap-sm rounded-xl overflow-hidden">
                <img className="w-full aspect-square object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAta5hvV58gxM_B5sGvDk6aDiHr9_ktZG5w3_9cS3qgP_EMqH1dglBoEXDhnA3F7kERllcVkBcBZWTmk7Y8jELXhm3jfrtTQFGIIK6hAg-J1AOA6XoP7iY6FiMxrHrWz6N3svwK-p5ZBpOvs3Lg7p-L-vro9zaHbyQ5ohgrr0ET29dUFmmy9nvg6xXejiXGNcmPeH8k2eQ8B6XoipmSp2dTuoM3bUD-BCXMB-dk1OS6S6lwMss8aPER_A7aLrfBgoqfffel6hYMSlA" />
                <img className="w-full aspect-square object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuANW_Y_hUEzmU8jPh0Kgb709wsyX8d6DNd1hr_3JgK-ZkAGC4r9vMz9-Uqpf49eLeYWZeTcgHas6EYhjF9eg6gHZ2fUHM-cS9QMpIIu3pcmUFxZC4MbKUhYwirGla2wok1DbSvqw692KrJZ_rXrUcf4xPxABigAC7AQht1hBKeq2nsYWHd2g6ULZ56ZBfcBn_7fuoDKZ9XYexnqiK1zdSIQf_MmDH7QfqzvAKYuwLsw6ztFuu8zdWBizp9nA2k725lnAGJLvKVqd0U" />
              </div>
            </div>
            <div className="p-md flex items-center gap-xl border-t border-outline-variant/10">
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-secondary transition-colors"><Icon name="favorite" /><span className="text-xs font-bold">89</span></button>
              <button className="flex items-center gap-xs text-on-surface-variant hover:text-primary transition-colors"><Icon name="chat_bubble" /><span className="text-xs font-bold">7</span></button>
            </div>
          </article>
        </div>
      </main>

      {/* Right sidebar */}
      <aside className="w-[350px] fixed right-0 top-0 h-screen p-lg hidden lg:flex flex-col gap-lg border-l border-outline-variant/30 overflow-y-auto">
        <section className="bg-surface-container-low rounded-2xl p-lg">
          <h2 className="text-title-md font-semibold text-on-surface mb-lg">O que está em alta</h2>
          <div className="space-y-md">
            {TRENDS.map((t) => (
              <div key={t.tag} className="group cursor-pointer">
                <p className="text-xs text-on-surface-variant">{t.cat}</p>
                <h4 className="font-bold text-on-surface group-hover:text-primary transition-colors">{t.tag}</h4>
                <p className="text-xs text-on-surface-variant">{t.posts}</p>
              </div>
            ))}
            <button className="text-primary text-sm font-bold mt-sm hover:underline">Mostrar mais</button>
          </div>
        </section>
        <section className="bg-surface-container-low rounded-2xl p-lg">
          <h2 className="text-title-md font-semibold text-on-surface mb-lg">Sugestões para seguir</h2>
          <div className="space-y-lg">
            {SUGGESTED.map((s) => (
              <div key={s.handle} className="flex items-center justify-between">
                <div className="flex items-center gap-sm">
                  <img alt="" className="w-10 h-10 rounded-full" src={s.img} />
                  <div>
                    <h4 className="text-sm font-bold text-on-surface">{s.name}</h4>
                    <p className="text-xs text-on-surface-variant">{s.handle}</p>
                  </div>
                </div>
                <button className="bg-on-surface text-surface text-xs font-bold px-md py-xs rounded-full hover:opacity-80 active:scale-95 transition-all">Seguir</button>
              </div>
            ))}
          </div>
        </section>
        <footer className="px-md">
          <div className="flex flex-wrap gap-sm text-[10px] text-on-surface-variant uppercase tracking-wider font-bold">
            <a className="hover:underline" href="#">Termos</a>
            <a className="hover:underline" href="#">Privacidade</a>
            <a className="hover:underline" href="#">Cookies</a>
            <a className="hover:underline" href="#">Sobre</a>
          </div>
          <p className="text-[10px] text-on-surface-variant/60 mt-sm">© 2024 ConnectFlow Inc.</p>
        </footer>
      </aside>
    </div>
  );
}
