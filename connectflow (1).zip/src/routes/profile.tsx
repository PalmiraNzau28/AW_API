import { createFileRoute } from "@tanstack/react-router";
import { Icon } from "@/components/Icon";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Perfil — ConnectFlow" },
      { name: "description", content: "Perfil de Gabriel Santos no ConnectFlow." },
    ],
  }),
  component: ProfilePage,
});

const TABS = ["Publicações", "Vídeos", "Curtidas", "Salvos"];

const GALLERY = [
  { span: "col-span-2 md:col-span-8 row-span-2 aspect-[16/10]", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuCMIfiIk6P-VPS2MjX-agexMXL9V4SfbEcTmDwzMhTg_ujGX-aJnsqHG3u__UvhwTLgfQCe3zZfhv74RuUFSQhxb44MMw84yMXE8yS_SeFeaARtLrW-S7QRHeKbfnE6H41GyLtuco0O4Z0WcUuuS0spL2DwQavxKqNvTdnLG91PP1NdcL59_F3SARFs4BZ4p8RUgBiAoFPnOUFzPRnlqslTzQNUXhVEJV0fzqP_cekxGmzX5fcC2-H_TgS2kc4NpNF0WfRy2xiN6mg", likes: "2.4k", comments: "152" },
  { span: "col-span-1 md:col-span-4 aspect-square", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuCavClLhJWBNOEAJVxvxjd7o2GXYt0YlOJ-B_UHL4RssE4j_LMo16bCI64oE9tGCDc7Z8dIHLuJofkIokwDuJV0fUEN2oysGn-LHsghsqr43lr6t7vVVuSK9DbmCY5WWTTm11xe69NG6vmCvpVW7dS32isc9Ertnh2LH8tvz4sdFrzG1Z0vfhayO2avSdw2V-T-o1yXm-CwyS7vLikPVq_J1_6t63on155fyhzFpM9pjjFWgztIgqZ3-En1oE8zp-EwaD3mUp11atY", likes: "842" },
  { span: "col-span-1 md:col-span-4 aspect-square", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuARvbBxO2YRAeDJKHFIK7TK3qhZDprnm5BQu0LrVmMQ-FphLsbpklFFdUTjgBTBcB7gxvRIVDMq_oZTj7AywpvzxlV_qkYi9cI6Y0ykaOm7kOyc2eLoMQsREYDnshMxYzLCl0SL6H2ewAy7eq5qdtkuUzuvsSrJwVsRWZjLpqIi3f3TYjhV_EcxOPgi3attuFCX3Yk61Y4hAgRwcNYxUJOw5rWO1CZBivV5b610KxgZFtKoZvhKUwHxNTQaF_EBf5tVnv3ozrQ7TPE", likes: "1.1k" },
  { span: "col-span-1 md:col-span-4 aspect-square", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDZu5GX9f-7o4dC1jAcg-gfnFqteWwOE5f88xZhmXtTCFdmnEYV0UixdBjaiizbOAMBDaZRCEp_iQBNKoLEC7dksUW9nKO2jHUx86j3mQMZ0Uu7aazHGBv2Lu1rdu4gNTAZp9fjUja7m07D-9iBqtXOQn2K7sOoYpM6rnlL0l8_4z0pKnuix40bc0axg2jp2zSTse4aSXPIR7rSCQLhVC0UY_08qqr3Qs9GQX46x6hMsCwKSu6140Ojypdx9EmYuWZfpN2N8GgkWAE", likes: "530" },
  { span: "col-span-1 md:col-span-4 aspect-square", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDbJgghJEVz9AA5Kv5Zn9PoUs9idtHsxn8H_h7e2Bk6H8GgVOCl-gk6r0mVNm1BnBolmKjOP5lCZEg3dN0cWkLjEDsKBS4FfyAuAmo_OuOTb9sFGTKTBcv8eP6G9rdgN3JOIp-g0Jwz8y1lvnIVuH9HFnbITjnjXJx7dtXNY0uhX6V5_6feFCRtpnbMy_d7WnffVbuRPi2S0DP1dKbB6orIcVQ-fviu_y6db7Ph8ZlmHqSPIvJNLVaWmhVuIyrgWJJOz99xTOXuZGU", likes: "921" },
  { span: "col-span-1 md:col-span-4 aspect-square", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAUw2Z9NCgZuDT31fuXxT4tbxG_-pskbuUPuo1h8rxyJp46HrLda6YBsDr3DNxpWTshR8bn9eClXCsahWXfLSCQwx0mdYpxOIlou2mdRoKbLxw3upWdUHw4mFC_0fkjrZcujQcwHS84KQFboA5jcvfNdZUeK4ot7mDQysCzGtA0pyS89eoNBitYkClvgF5aHRCiGvGLlXN2qKC0ChowNlE94xBq704V8EHP-mWI2OZxbLlU_LTrgD3Q2XdVyDxrXmz45ayzhNYqiBk", likes: "760" },
];

function ProfilePage() {
  return (
    <main className="md:ml-64 min-h-screen pb-24 md:pb-0">
      <section className="relative">
        <div className="h-64 md:h-80 w-full overflow-hidden relative">
          <img className="w-full h-full object-cover" alt="" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCVJPEGtPYpaR-DAG3v7CJFOussCbYpJB2dR1J6Y8n4mUOJ-apn83QgeYgAIch8JteQM0c5ZFjLimC6Wm9sMwfigsdVjm973pKCxtbFeL5QxkSGvvykORsa_8gGP2UrZCUF4RGeTT5Q8pYCquCqxaWXAiwUKf1_tl0QMiaDhBaCLmwUkv6SyvWmVHsVAtmWdV9tXx4aMk4_imHUtHjK2JFH7CMxq5moHU-pgoZKbzHYmiqRAvHwx7U6DFeM_s3lL-FtIkk0pdcFuG8" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
        </div>
        <div className="max-w-[1200px] mx-auto px-lg md:px-xl relative">
          <div className="flex flex-col md:flex-row items-start md:items-end gap-lg -mt-20 relative z-10">
            <div className="p-1 bg-surface-container-lowest rounded-full shadow-lg">
              <img alt="Avatar" className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-surface-container-lowest object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuACiom_xI0pzb-4GxvBdeMkBDRJyVrOCtndCx0xwsYYCr0pq8TKKAd0puLW1WkY8kmGo0bTq411Tgy4BdgxKLDa7dPFAmPgl4xHAiePPmq7oN6hvnjb5_lPyx0J1D79Fr9jD3BC1nb0mut0E1Zl5HoEOl0_zWBC12frih1HUY2wIuZ-eavGqpfnDAau1QaTVpTxk4VcJ1W4IgGthBA0eSCtsp46gn-aA6Zyl43A9KCdQYVX3AxIjkb4Fm1jnyOhOLp-5sV8FiqEcgI" />
            </div>
            <div className="flex-1 pb-base md:mb-2 w-full">
              <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-md w-full">
                <div>
                  <h1 className="text-headline-lg-mobile md:text-headline-lg font-bold text-on-surface flex items-center gap-xs">
                    Gabriel Santos
                    <Icon name="verified" filled className="text-primary !text-2xl" />
                  </h1>
                  <p className="text-on-surface-variant text-body-lg">@gabriel_design • UX Designer &amp; Creative Thinker</p>
                </div>
                <div className="flex gap-md">
                  <button className="px-lg py-sm bg-surface-container-high text-on-surface font-bold rounded-xl hover:bg-surface-container-highest transition-colors active:scale-95">Editar Perfil</button>
                  <button className="px-lg py-sm bg-primary-container text-on-primary-container font-bold rounded-xl shadow-sm hover:brightness-110 transition-all active:scale-95">Seguir</button>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-xl mt-xl pb-xl border-b border-outline-variant">
            <div className="col-span-12 md:col-span-5 space-y-md">
              <p className="text-body-lg text-on-surface leading-relaxed">
                Apaixonado por criar experiências digitais fluidas e significativas. Atualmente explorando o cruzamento entre IA e interfaces generativas. 🎨✨
              </p>
              <div className="flex flex-wrap gap-md text-on-surface-variant">
                <div className="flex items-center gap-xs"><Icon name="location_on" className="!text-base" /><span className="text-label-md">São Paulo, Brasil</span></div>
                <div className="flex items-center gap-xs"><Icon name="link" className="!text-base" /><a className="text-label-md text-primary hover:underline" href="#">gabrielsantos.design</a></div>
                <div className="flex items-center gap-xs"><Icon name="calendar_today" className="!text-base" /><span className="text-label-md">Entrou em Maio 2022</span></div>
              </div>
            </div>
            <div className="col-span-12 md:col-span-7">
              <div className="flex gap-xl justify-start md:justify-end">
                {[["142", "Posts"], ["12.8k", "Seguidores"], ["892", "Seguindo"]].map(([n, l]) => (
                  <div key={l} className="text-center group cursor-pointer">
                    <p className="text-display-lg font-bold text-primary group-hover:scale-105 transition-transform">{n}</p>
                    <p className="text-label-md text-on-surface-variant uppercase tracking-widest">{l}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-[1200px] mx-auto px-lg md:px-xl py-lg">
        <div className="flex gap-xl mb-xl border-b border-outline-variant overflow-x-auto hide-scrollbar">
          {TABS.map((t, i) => (
            <button
              key={t}
              className={`pb-md border-b-4 text-title-md whitespace-nowrap transition-all ${i === 0 ? "border-primary text-primary font-bold" : "border-transparent text-on-surface-variant font-medium hover:text-on-surface"}`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-12 gap-md">
          {GALLERY.map((g, i) => (
            <div key={i} className={`${g.span} group relative overflow-hidden rounded-xl`}>
              <img className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="" src={g.img} />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-md text-white">
                <div className="flex items-center gap-xs"><Icon name="favorite" /> {g.likes}</div>
                {g.comments && <div className="flex items-center gap-xs"><Icon name="chat_bubble" /> {g.comments}</div>}
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
