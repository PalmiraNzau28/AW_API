import { createFileRoute } from "@tanstack/react-router";
import { Icon } from "@/components/Icon";

export const Route = createFileRoute("/messages")({
  head: () => ({ meta: [{ title: "Mensagens — ConnectFlow" }] }),
  component: () => (
    <main className="md:ml-64 min-h-screen pb-24 md:pb-0 flex items-center justify-center">
      <div className="text-center max-w-sm px-lg">
        <div className="w-20 h-20 rounded-full bg-primary-container text-on-primary-container flex items-center justify-center mx-auto mb-lg">
          <Icon name="mail" filled className="!text-4xl" />
        </div>
        <h1 className="text-headline-lg-mobile font-bold mb-sm">Suas mensagens</h1>
        <p className="text-on-surface-variant text-body-md">Envie e receba mensagens diretas de pessoas que você segue.</p>
      </div>
    </main>
  ),
});
