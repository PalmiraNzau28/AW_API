import { createFileRoute } from "@tanstack/react-router";
import { Icon } from "@/components/Icon";

export const Route = createFileRoute("/explore")({
  head: () => ({
    meta: [
      { title: "Explorar — ConnectFlow" },
      { name: "description", content: "Descubra tendências, criadores e tópicos no ConnectFlow." },
    ],
  }),
  component: ExplorePage,
});

const CATS = ["Para Você", "Trending", "Design", "Tecnologia", "Viagens", "Arquitetura", "Moda"];

const SUGGESTED = [
  { name: "Ana Silva", handle: "@anadesign", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDzL2F961PmqQF7OJjNOdCa5otLdCsEYK--bMEQiIdGfEFCHmBlkKCycD0haLEABrPrcYM5x9TcwDhA4v8wpN8467YdfL6WEWiTYBr8g-z5Juy1qDR7E_mK3675-DyjN_j18KiTQRfgsgR25PWa2fN18bdru5xMx9A2OpO34sZQ4AIQbcBtwAlHEB4LYSIX4KLlP4gyfdF0dTMqkLXWi-WqShzGeTnaUTBfE93kFCxGW3Lwcb5QFBxRVvUR1a_gLH0H_sC7HWhjAeU" },
  { name: "Marco Polo", handle: "@explorer_marco", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDKsmS_faPZIWvca8ZMYbgFawNac8S8QvhI_f85pAkQBJ9zOsODhooB5B-cBbogvoAsQNVf6ZUvl-dkakrKmx29NwyDQXvJHQ3pQXGx8SwRTNEwpAxRdrU9CXd-aY3rd-ArUKi-ADg38iO6FsaKTDh2jb-M_tfomm7547oOyiKebRLGBPwMtcSWQ609v7y-Ra7lujSIXHACw5ao-_hOeUmb9Hj88d7UQrF6vOl4jI-blB99-1lmVjvkeB2vMfMwW3bETQ9nAQa85PI" },
  { name: "Clara Luz", handle: "@claraluz_art", img: "https://lh3.googleusercontent.com/aida-public/AB6AXuA4MWZQeETigvVL-ZIZkg9luP10f1SKMEE34TyE1BFPRHH0goueNZpx590kTQo8fAmxrZHinlzuJDocjg4PkMLROy3bO2tvr2aVUyqG6_IH9fK8xkpdH9qSF5av0tyuGpMBjbN_fc0OE4oY219PGguEsAVJQDt0oFtrwEtCKPDTNeA6MRIX5xi8yUynGGdBPO6s0eIXm2zvmcCcwzBTTWKfvhVb6G27RlL9vWhqA1f-ItAaKWdyT9KAiiBQmA52hux4XrUqXp4ki7M" },
];

function ExplorePage() {
  return (
    <main className="md:ml-64 min-h-screen pb-24 md:pb-0">
      <header className="sticky top-0 z-40 bg-surface/80 backdrop-blur-md px-lg md:px-xl py-md flex items-center justify-between gap-xl">
        <div className="flex-1 max-w-2xl relative">
          <Icon name="search" className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" />
          <input
            type="text"
            placeholder="Explorar tendências, pessoas e tópicos..."
            className="w-full pl-12 pr-4 py-3 bg-surface-container-lowest border border-outline-variant rounded-full focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
          />
        </div>
        <div className="flex items-center gap-md">
          <button className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:bg-surface-container-high transition-all active:scale-90"><Icon name="notifications" /></button>
          <button className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:bg-surface-container-high transition-all active:scale-90"><Icon name="chat_bubble" /></button>
        </div>
      </header>

      <section className="px-lg md:px-xl py-base">
        <div className="flex items-center gap-sm overflow-x-auto hide-scrollbar pb-md">
          {CATS.map((c, i) => (
            <button
              key={c}
              className={`px-lg py-sm rounded-full whitespace-nowrap text-label-md font-bold transition-colors ${i === 0 ? "bg-primary text-on-primary" : "bg-surface-container-high text-on-surface-variant hover:bg-surface-container-highest"}`}
            >
              {c}
            </button>
          ))}
        </div>
      </section>

      <section className="px-lg md:px-xl pb-xl">
        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[240px] gap-md">
          <div className="col-span-2 row-span-2 relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCFraneZvE-cCE30bTap8mTu11jqPhiZwHm7E-s1npgfIN7L_REShJ3Wxz9lSM8y_VMSDeU6r2TYWKM5OZUJRhyLRGyvNVLgGYZYyOtVXu7kgqlNh_bdanAc8itgOkv2yuNLc_SS8PVtxS22b3PRgvklOvoHpXL3Zw85p1l3GwP_9qQ4Uu4etjfHMk-V9lnXYmF_62eVIWm9BB3liKLdxNnBo0UreybxcjyoCmQ8g1nqnbxEbxjm2KGXPqPTgQhxaphReWpOUjinsA" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-lg">
              <span className="bg-secondary-container text-on-secondary-container text-[10px] font-bold px-sm py-1 rounded-full w-fit mb-sm uppercase tracking-wider">Destaque</span>
              <h3 className="text-white text-headline-lg-mobile font-bold leading-tight">O Futuro da Inteligência Artificial em 2024</h3>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCAMedrkyiodqUqFkwfnLEdyDm0EpLyVqghgSd0ZArDXp1LOIPp2SuBQPQVFOZa8QOoJy4V9_paU6ozmgib9oWTmFiNLSg89mZWbetW2cS9vwWiprNA5rwxXQGpdnDjWBsmj43zWAvz_iCPtHa7y_6IZ7CwjwrYaCJ0yYkrZeIYHGkeDLEu-SdYBqac7F6ijOaNtAYzkNCH5G2nwS1ibr0rlAKgMQbbIshjI_tgdvdc1Q6bDdLY1uE1WFW4n1NMcaNHoHNzl82wMGk" />
          </div>
          <div className="relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCJFBfBkhnZ4abCeG0VdHTqldFZeSQrwlM-1-drq_Y3gm6JKe5W8xu2QgtDf4nZaQWmkhhtAuB8YH9J-ZC0DUCd44iSn5i5jV05B6fskfApJM9fzAt9hfDo0NRdy5QrmUhBk2e8Kn75KxS59FNMFUHFitTuCf5Vjg3nWl8QWLAqhi-QyYFF6r1JDlorpoeCFXt3IHnrsDmSK-LXoWsYXhGMMcOTxnzSjYmudCHiog8F7Wraneue5gPnK6mlwV-T4V6SHUv8n3I_g9A" />
          </div>
          <div className="row-span-2 relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBufwsJZsxo8f5Q6AdsiqqBcRXwoWQZ40sqx2bIHm2JgDMxFEBWA-ABOBEGdIf6pzJifZSIxO_vt2rOxxP1tpjlcU0Wb4bHHELILNxd7FH8K93DWmvIC_rSIQo-0PxYtUH_YXzmrp68SgO1xrIE_jqJv9uXBenYNnQVjRPuV1lZ7lTDy352h6LyqpCMWEW2nadcpKb81AP9Yz9vNRyZ0uy5rmSegrtBdeYCz9N41lMHNBabx98vE9OuKgo-yRut8qSbGYobEdjqENM" />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
              <Icon name="play_circle" filled className="text-white !text-5xl" />
            </div>
          </div>
          <div className="relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDBJ35V4dCdto5GyVm-nNZ76pNhv-gWLk0IzVvnkSjf-y1_2mkMXn_ukZLHmfhKkhL1pp4yehgMrecoez6yygzTEsIbjq6RGO-ycyvs6_PmJbPRXMUZOblq2z_TAv94Ly8bgottlDhVHU8TZYNXHdauQ5mBTM86K6CMNtLId0DutS9wCZV0BT1fI-SbnzLrYK4YLZmrozF0A4B1_w2FQ8CNbRt_Dkn08SKCidADI7BQ1anc-4S3s4NxdS4ihDVG2LKGKf8B2GPuMMM" />
          </div>
          <div className="col-span-2 relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDcXJXzstMdbjDHgx3bdsDFpE4PTjaZy3NzvNkynG65Q0AlSmHBW6-AhiNkbmPgnP76B3pncpJpnTFGzRMlMPyLx4YAOAf-SyAzjy9Ni7-RgYxP4iwF4-Eb0EKeEOuOWM0FVTV7-LCcGB21pns5KQfLy-JTVUs1xQEQDt0B-MoRG37rwVPXcratrQsDHBlgnP0GREh8xz3W5XgyryBJ2b5Qgi8p22NfEumXq9JBIY1nWapN64bTDaouaDITDNYV5bO2AfahuFtUQ0Q" />
            <div className="absolute top-4 right-4 bg-surface-container-lowest/80 backdrop-blur px-sm py-1 rounded-full flex items-center gap-xs">
              <Icon name="visibility" className="!text-base" />
              <span className="text-[10px] font-bold">1.2k</span>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-xl group cursor-pointer">
            <img alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCVsH3OCJwRt_0V8NV-HhWWl3Em-Wkb4bvOF6VrvZ_Q3VunD0FUCoiJuYxRA_lD57s7tlwyQIJ-QN4KwwZDkg4sn2XaSsTuwgvJuluuizctaX9jhwO79I0RpswCxbk5sV2mhD0uYCZW4clB5Vn39D_mZDoIXplAgbAM1XLKuqbrPItjt76okODpCPwOrpPvqQe3ESSIS8zt54uhaAvMJ7nh1EGzPmJLhfoOy8m-3WYaTAcWH7FOas5l4tpd0gh6n9UFN0KNtO_hHl0" />
          </div>
        </div>

        <div className="mt-xl">
          <div className="flex items-center justify-between mb-lg">
            <h2 className="text-headline-lg-mobile font-bold text-on-surface">Sugestões para seguir</h2>
            <a className="text-primary font-bold hover:underline" href="#">Ver tudo</a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
            {SUGGESTED.map((s) => (
              <div key={s.handle} className="bg-surface-container-lowest p-lg rounded-xl flex items-center gap-md shadow-sm border border-outline-variant/30 transition-transform hover:-translate-y-1">
                <img alt="" className="w-14 h-14 rounded-full" src={s.img} />
                <div className="flex-1">
                  <h4 className="font-bold text-title-md">{s.name}</h4>
                  <p className="text-on-surface-variant text-xs">{s.handle}</p>
                </div>
                <button className="bg-secondary text-on-secondary font-bold px-lg py-sm rounded-full text-xs active:scale-95 transition-transform">Seguir</button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
