import { cn } from "@/lib/utils";

export function Icon({
  name,
  filled,
  className,
  style,
}: {
  name: string;
  filled?: boolean;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <span
      className={cn("material-symbols-outlined", filled && "filled", className)}
      style={style}
      aria-hidden="true"
    >
      {name}
    </span>
  );
}
