import { Link, useRouterState } from "@tanstack/react-router";
import { Icon } from "./Icon";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", icon: "home", label: "Feed" },
  { to: "/explore", icon: "explore", label: "Explorar" },
  { to: "/notifications", icon: "notifications", label: "Notificações" },
  { to: "/messages", icon: "mail", label: "Mensagens" },
  { to: "/profile", icon: "person", label: "Perfil" },
] as const;

export function Sidebar() {
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <>
      <aside className="h-screen w-64 fixed left-0 top-0 bg-surface flex flex-col p-md border-r border-outline-variant z-50 hidden md:flex">
        <div className="mb-xl px-md">
          <span className="font-headline-lg text-headline-lg font-bold text-primary tracking-tight">
            ConnectFlow
          </span>
        </div>
        <nav className="flex-1 flex flex-col gap-base">
          {NAV.map((item) => {
            const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-md rounded-xl px-md py-sm transition-all active:scale-[0.98]",
                  active
                    ? "bg-primary-container text-on-primary-container font-bold"
                    : "text-on-surface-variant hover:bg-surface-container-high",
                )}
              >
                <Icon name={item.icon} filled={active} />
                <span className="text-label-md">{item.label}</span>
              </Link>
            );
          })}
          <button className="mt-lg w-full bg-primary-container text-on-primary-container py-md rounded-full font-bold shadow-sm hover:brightness-110 active:scale-95 transition-all">
            Criar Post
          </button>
        </nav>
        <div className="mt-auto pt-md border-t border-outline-variant flex flex-col gap-xs">
          <div className="flex items-center gap-md px-md py-sm mb-sm">
            <img
              alt="Avatar"
              className="w-10 h-10 rounded-full border border-outline-variant object-cover"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCEimCiyh6yE9HZ3X2NGIzaplwgD-nZsxUCSznFAtIio_HriRkn6Gb0R1zLkDcNZxtCIahfhGIDVppv55VxINcF7NzSlOzGKP0KP15mGaqpTgxNn-skGU19Uc_l6cnopKuZkfcvsxkI3jO3_RPlFNGa-2mAFeCKbgEZjcKS66_aVixiHv8ay3sjUaP1-7Av1jdkPM5VCcmFakgg0CDNbAUsSGhidv0lZN3qUj6sTTQHKazoH56P47mCXWpGDQ0PRcysX2CgnzTQEwI"
            />
            <div className="flex flex-col overflow-hidden">
              <span className="text-body-md font-bold truncate">Usuário Ativo</span>
              <span className="text-on-surface-variant text-xs truncate">@usuario_conectado</span>
            </div>
          </div>
          <a className="flex items-center gap-md text-on-surface-variant hover:bg-surface-container-high rounded-xl px-md py-sm transition-all" href="#">
            <Icon name="settings" />
            <span className="text-label-md">Configurações</span>
          </a>
          <a className="flex items-center gap-md text-secondary hover:bg-error-container/40 rounded-xl px-md py-sm transition-all" href="#">
            <Icon name="logout" />
            <span className="text-label-md">Sair</span>
          </a>
        </div>
      </aside>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-surface-container-lowest flex justify-around items-center p-sm md:hidden z-50 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        {NAV.map((item) => {
          const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex flex-col items-center gap-xs px-sm py-xs active:scale-95 transition-transform",
                active ? "text-primary" : "text-on-surface-variant",
              )}
            >
              <Icon name={item.icon} filled={active} />
            </Link>
          );
        })}
      </nav>
    </>
  );
}
